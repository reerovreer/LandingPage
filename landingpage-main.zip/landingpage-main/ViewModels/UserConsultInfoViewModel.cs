namespace LandingPage.ViewModels;

public class UserConsultInfoViewModel
{
    public string UserName { get; set; }
    public string PhoneNumber { get; set; }
}