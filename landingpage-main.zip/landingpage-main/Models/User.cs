using Microsoft.AspNetCore.Identity;

namespace LandingPage.Models;

public class User : IdentityUser
{
}